"""
Student Grade Calculator
A simple beginner-friendly Python command-line application.
"""

def get_mark(subject):
    """Read and validate a mark between 0 and 100."""
    while True:
        try:
            mark = float(input(f"Enter marks for {subject} (0-100): "))
            if 0 <= mark <= 100:
                return mark
            print("Please enter a mark between 0 and 100.")
        except ValueError:
            print("Invalid input. Please enter a number.")


def calculate_grade(average):
    """Return a letter grade based on the average mark."""
    if average >= 90:
        return "A+"
    elif average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 50:
        return "D"
    else:
        return "F"


def main():
    print("=" * 38)
    print("       STUDENT GRADE CALCULATOR")
    print("=" * 38)

    student_name = input("Enter student name: ").strip()
    if not student_name:
        student_name = "Student"

    subjects = ["Python", "Mathematics", "Computer Science"]
    marks = {}

    for subject in subjects:
        marks[subject] = get_mark(subject)

    total = sum(marks.values())
    average = total / len(subjects)
    grade = calculate_grade(average)
    result = (
        "PASS"
        if average >= 40 and all(mark >= 35 for mark in marks.values())
        else "NEEDS IMPROVEMENT"
    )

    print("\n" + "-" * 38)
    print(f"Student: {student_name}")
    print("-" * 38)
    for subject, mark in marks.items():
        print(f"{subject:<22} {mark:>6.1f}")
    print("-" * 38)
    print(f"{'Total':<22} {total:>6.1f} / {len(subjects) * 100}")
    print(f"{'Average':<22} {average:>6.2f}%")
    print(f"{'Grade':<22} {grade}")
    print(f"{'Result':<22} {result}")
    print("-" * 38)


if __name__ == "__main__":
    main()
