# Student Grade Calculator

A beginner-friendly command-line Python application that accepts a student's name and marks in three subjects, then calculates the total, average, grade, and result.

## Requirements
- Python 3.8 or later
- No external libraries required

## Run the application
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run `python app.py` (or `python3 app.py` on some systems).

## Features
- Accepts marks for Python, Mathematics, and Computer Science.
- Validates marks from 0 to 100 and handles non-numeric input.
- Calculates total and average.
- Assigns a letter grade.
- Shows PASS when the average is at least 40 and every subject mark is at least 35; otherwise shows NEEDS IMPROVEMENT.

## Grade scale
- 90–100: A+
- 80–89.99: A
- 70–79.99: B
- 60–69.99: C
- 50–59.99: D
- Below 50: F

This is an educational project. Change the grading thresholds if your institution uses different rules.
